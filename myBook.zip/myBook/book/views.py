from django.shortcuts import render
from django.views.generic import ListView
from book.models import Livro


class indexView(ListView):
    model = Livro
    template_name = "index.html"
    paginated_by = 1

    def image(request):
   livrox = Livro.objects.all()
   for mylivro in livrox:
       MyLivro = mylivro.photo.url
   variables = RequestContext(request,{
       'livrox':MyLivro
})
return render_to_response('index.html',variables)