from django.db import models

class Categoria(models.Model):
    id = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=100, blank=False)
    categorias = models.Manager()

    def __str__(self):
       return u'%s' % self.nome

class Meta:
    managed = True

class Livro(models.Model):
    id = models.AutoField(primary_key=True)
    titulo = models.CharField(max_length=255)
    preço = models.DecimalField(max_digits=5, decimal_places=2)
    imagem = models.ImageField(upload_to= "media/livros/%Y/%m/%D/", verbose_name="Imagem do Livro", help_text="Escolha a imagem do seu livro.")
    sinopse = models.TextField(verbose_name=u'Sinopse')
    slug = models.SlugField(blank=False)
    livros = models.Manager()
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)